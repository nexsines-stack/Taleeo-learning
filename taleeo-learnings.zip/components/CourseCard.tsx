import React from 'react';
import { Clock, ArrowRight } from 'lucide-react';
import { Course } from '../types';
import Button from './Button';

interface CourseCardProps {
  course: Course;
}

const CourseCard: React.FC<CourseCardProps> = ({ course }) => {
  return (
    <div className="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 border border-slate-100 flex flex-col h-full">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={course.image} 
          alt={course.title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-brand-700 uppercase tracking-wide">
          {course.category}
        </div>
      </div>
      
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-xl font-bold text-slate-900 mb-2 line-clamp-2 group-hover:text-brand-600 transition-colors">
          {course.title}
        </h3>
        <p className="text-slate-600 text-sm mb-4 line-clamp-2 flex-grow">
          {course.description}
        </p>
        
        <div className="flex items-center text-slate-500 text-sm mb-6">
          <Clock className="w-4 h-4 mr-2" />
          <span>{course.duration}</span>
        </div>
        
        <Button variant="outline" to="/contact" fullWidth className="group-hover:bg-brand-600 group-hover:text-white group-hover:border-transparent mt-auto">
          Enroll Now <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};

export default CourseCard;