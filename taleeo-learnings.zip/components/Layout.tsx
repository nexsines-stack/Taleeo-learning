import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Mail, MapPin, Facebook, Instagram, Linkedin, Twitter } from 'lucide-react';
import { COMPANY_INFO, NAV_LINKS } from '../constants';
import Button from './Button';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  // Close menu on route change
  useEffect(() => {
    setIsMenuOpen(false);
    window.scrollTo(0, 0);
  }, [location]);

  // Handle scroll for sticky header shadow
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen flex flex-col font-sans">
      {/* Top Bar */}
      <div className="bg-brand-900 text-slate-200 py-2 text-xs md:text-sm hidden md:block">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex space-x-6">
            <span className="flex items-center hover:text-white transition-colors">
              <Phone className="w-3 h-3 mr-2" /> {COMPANY_INFO.phone}
            </span>
            <span className="flex items-center hover:text-white transition-colors">
              <Mail className="w-3 h-3 mr-2" /> {COMPANY_INFO.email}
            </span>
          </div>
          <div className="flex space-x-4">
             <span className="opacity-75">Connect with us:</span>
             <div className="flex space-x-3">
               <a href="#" className="hover:text-white"><Linkedin className="w-3 h-3" /></a>
               <a href="#" className="hover:text-white"><Instagram className="w-3 h-3" /></a>
             </div>
          </div>
        </div>
      </div>

      {/* Header */}
      <header 
        className={`sticky top-0 z-50 bg-white transition-all duration-300 ${
          isScrolled ? 'shadow-lg py-3' : 'border-b border-gray-100 py-4'
        }`}
      >
        <div className="container mx-auto px-4 flex justify-between items-center">
          <Link to="/" className="flex items-center group">
            <div className="w-10 h-10 bg-brand-600 rounded-lg flex items-center justify-center text-white font-bold text-xl mr-3 group-hover:rotate-6 transition-transform">
              TL
            </div>
            <span className="text-2xl font-bold text-slate-800 tracking-tight">
              TALeeO <span className="text-brand-600">Learnings</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center space-x-8">
            {NAV_LINKS.map((link) => (
              <Link 
                key={link.name}
                to={link.path} 
                className={`text-sm font-medium transition-colors hover:text-brand-600 ${
                  location.pathname === link.path ? 'text-brand-600' : 'text-slate-600'
                }`}
              >
                {link.name}
              </Link>
            ))}
            <Button variant="primary" to="/webinars" className="px-5 py-2 text-sm">
              Free Webinar
            </Button>
          </nav>

          {/* Mobile Menu Toggle */}
          <button 
            className="lg:hidden p-2 text-slate-600"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Nav Dropdown */}
        {isMenuOpen && (
          <div className="absolute top-full left-0 w-full bg-white shadow-xl border-t border-gray-100 lg:hidden flex flex-col p-4 space-y-4">
            {NAV_LINKS.map((link) => (
              <Link 
                key={link.name}
                to={link.path} 
                className={`text-base font-medium p-2 rounded-lg hover:bg-slate-50 ${
                   location.pathname === link.path ? 'text-brand-600 bg-slate-50' : 'text-slate-600'
                }`}
              >
                {link.name}
              </Link>
            ))}
            <Button variant="primary" to="/webinars" fullWidth>
              Register for Webinar
            </Button>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-300 pt-16 pb-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            
            {/* Column 1: Brand */}
            <div>
              <div className="flex items-center mb-6">
                 <div className="w-8 h-8 bg-brand-500 rounded flex items-center justify-center text-white font-bold text-sm mr-2">
                  TL
                </div>
                <span className="text-xl font-bold text-white">TALeeO Learnings</span>
              </div>
              <p className="text-sm leading-relaxed mb-6">
                Bridging the gap between education and employment with practical, industry-focused training.
              </p>
              <div className="flex space-x-4">
                <a 
                  href="#" 
                  aria-label="Facebook"
                  className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:bg-blue-600 hover:text-white transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
                >
                  <Facebook className="w-5 h-5" />
                </a>
                <a 
                  href="#" 
                  aria-label="Instagram"
                  className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:bg-pink-600 hover:text-white transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
                >
                  <Instagram className="w-5 h-5" />
                </a>
                <a 
                  href="#" 
                  aria-label="LinkedIn"
                  className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:bg-blue-700 hover:text-white transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
                >
                  <Linkedin className="w-5 h-5" />
                </a>
                <a 
                  href="#" 
                  aria-label="Twitter"
                  className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:bg-sky-500 hover:text-white transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
                >
                  <Twitter className="w-5 h-5" />
                </a>
              </div>
            </div>

            {/* Column 2: Quick Links */}
            <div>
              <h4 className="text-white font-semibold mb-6">Quick Links</h4>
              <ul className="space-y-3 text-sm">
                <li><Link to="/about" className="hover:text-brand-400 transition-colors">About Us</Link></li>
                <li><Link to="/programs" className="hover:text-brand-400 transition-colors">All Programs</Link></li>
                <li><Link to="/internships" className="hover:text-brand-400 transition-colors">Careers</Link></li>
                <li><Link to="/contact" className="hover:text-brand-400 transition-colors">Contact</Link></li>
              </ul>
            </div>

            {/* Column 3: Policies */}
            <div>
              <h4 className="text-white font-semibold mb-6">Policies</h4>
              <ul className="space-y-3 text-sm">
                <li><Link to="/policies" className="hover:text-brand-400 transition-colors">Privacy Policy</Link></li>
                <li><Link to="/policies" className="hover:text-brand-400 transition-colors">Terms & Conditions</Link></li>
                <li><Link to="/policies" className="hover:text-brand-400 transition-colors">Refund Policy</Link></li>
              </ul>
            </div>

            {/* Column 4: Contact */}
            <div>
              <h4 className="text-white font-semibold mb-6">Contact Us</h4>
              <ul className="space-y-4 text-sm">
                <li className="flex items-start">
                  <MapPin className="w-5 h-5 mr-3 text-brand-500 flex-shrink-0" />
                  <span>{COMPANY_INFO.address}</span>
                </li>
                <li className="flex items-center">
                  <Phone className="w-5 h-5 mr-3 text-brand-500 flex-shrink-0" />
                  <a href={`tel:${COMPANY_INFO.phone}`} className="hover:text-white">{COMPANY_INFO.phone}</a>
                </li>
                <li className="flex items-center">
                  <Mail className="w-5 h-5 mr-3 text-brand-500 flex-shrink-0" />
                  <a href={`mailto:${COMPANY_INFO.email}`} className="hover:text-white">{COMPANY_INFO.email}</a>
                </li>
              </ul>
            </div>

          </div>
          
          <div className="border-t border-slate-800 pt-8 text-center text-sm text-slate-500">
            &copy; {new Date().getFullYear()} TALeeO Learnings. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;