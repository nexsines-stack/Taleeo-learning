import { 
  Briefcase, 
  MonitorPlay, 
  Users, 
  Wallet, 
  BarChart, 
  PieChart, 
  TrendingUp, 
  Globe 
} from 'lucide-react';
import { Course, Feature, Internship, Testimonial, Webinar } from './types';

export const COMPANY_INFO = {
  name: "TALeeO Learnings",
  phone: "+91-9989706655",
  email: "taleeolearnings@gmail.com",
  address: "Hyderabad, India"
};

export const NAV_LINKS = [
  { name: 'Home', path: '/' },
  { name: 'Programs', path: '/programs' },
  { name: 'Webinars', path: '/webinars' },
  { name: 'Internships', path: '/internships' },
  { name: 'About', path: '/about' },
  { name: 'Contact', path: '/contact' },
];

export const FEATURES: Feature[] = [
  {
    id: 1,
    title: "Practical First Approach",
    description: "We focus on hands-on labs and real-world simulations rather than just theory.",
    icon: MonitorPlay
  },
  {
    id: 2,
    title: "Industry-Relevant Trainers",
    description: "Learn directly from mentors who are currently working in top MNCs.",
    icon: Users
  },
  {
    id: 3,
    title: "Career-Focused Learning",
    description: "Curriculum designed specifically to crack interviews and excel in jobs.",
    icon: Briefcase
  },
  {
    id: 4,
    title: "Affordable & Accessible",
    description: "High-quality education at a price point that doesn't break the bank.",
    icon: Wallet
  }
];

export const COURSES: Course[] = [
  {
    id: 'excel-powerbi',
    title: "Advanced Excel & Power BI",
    category: "Data",
    description: "Master data visualization and reporting with the industry's top tools.",
    duration: "6 Weeks",
    image: "https://picsum.photos/id/48/800/600"
  },
  {
    id: 'business-analytics',
    title: "Business Analytics & Project Management",
    category: "Business",
    description: "Learn to interpret data to drive business decisions and manage projects efficiently.",
    duration: "8 Weeks",
    image: "https://picsum.photos/id/3/800/600"
  },
  {
    id: 'digital-marketing',
    title: "Digital & Performance Marketing",
    category: "Marketing",
    description: "Become a full-stack marketer mastering SEO, SEM, and Social Media strategies.",
    duration: "10 Weeks",
    image: "https://picsum.photos/id/60/800/600"
  },
  {
    id: 'career-readiness',
    title: "Career Readiness & Placement Prep",
    category: "Business",
    description: "Resume building, mock interviews, and soft skills to land your dream job.",
    duration: "4 Weeks",
    image: "https://picsum.photos/id/20/800/600"
  },
  {
    id: 'entrepreneurship',
    title: "Start Your Business From Scratch",
    category: "Business",
    description: "A-Z guide on launching a startup, from ideation to first revenue.",
    duration: "12 Weeks",
    image: "https://picsum.photos/id/4/800/600"
  },
  {
    id: 'web-dropshipping',
    title: "Website Management & Dropshipping",
    category: "Tech",
    description: "Build e-commerce stores and manage online businesses without inventory.",
    duration: "8 Weeks",
    image: "https://picsum.photos/id/180/800/600"
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    name: "Priya Sharma",
    role: "Data Analyst at TechCorp",
    content: "The Power BI course was a game changer. I moved from a support role to an analyst role within 3 months.",
    avatar: "https://picsum.photos/id/64/150/150"
  },
  {
    id: 2,
    name: "Rahul Verma",
    role: "Digital Marketing Freelancer",
    content: "TALeeO's practical approach helped me launch my own agency. The mentorship is top-notch.",
    avatar: "https://picsum.photos/id/91/150/150"
  },
  {
    id: 3,
    name: "Sneha Reddy",
    role: "MBA Graduate",
    content: "I lacked confidence in interviews. The placement prep module gave me the clarity I needed.",
    avatar: "https://picsum.photos/id/177/150/150"
  }
];

export const WEBINARS: Webinar[] = [
  {
    id: "w1",
    title: "Data Science Roadmap 2024",
    date: "Oct 25, 2024",
    time: "7:00 PM IST",
    speaker: "Dr. Ankit Mehta, Sr. Data Scientist",
    topics: ["Market Trends", "Tools to Learn", "Q&A Session"]
  },
  {
    id: "w2",
    title: "Mastering LinkedIn for Jobs",
    date: "Oct 28, 2024",
    time: "6:00 PM IST",
    speaker: "Sarah Jones, HR Manager",
    topics: ["Profile Optimization", "Networking Hacks", "Live Profile Review"]
  }
];

export const INTERNSHIPS: Internship[] = [
  {
    id: "int-1",
    role: "Business Development Intern",
    type: "Remote / Hybrid",
    location: "India",
    description: "Learn how to generate leads, manage client relationships, and close deals in a fast-paced environment.",
    benefits: ["Performance Stipend", "Certificate of Experience", "Pre-Placement Offer (PPO) potential"]
  },
  {
    id: "int-2",
    role: "Digital Marketing Intern",
    type: "Remote",
    location: "India",
    description: "Work on live campaigns, manage social media calendars, and analyze performance metrics.",
    benefits: ["Live Ad Budget Exposure", "Mentorship from Experts", "Flexible Hours"]
  }
];