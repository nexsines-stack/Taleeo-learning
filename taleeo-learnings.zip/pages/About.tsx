import React from 'react';
import Layout from '../components/Layout';
import { Target, Lightbulb, Users, ArrowRight } from 'lucide-react';
import Button from '../components/Button';

const About: React.FC = () => {
  return (
    <Layout>
      {/* Header */}
      <div className="bg-slate-900 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">About TALeeO Learnings</h1>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            We are on a mission to bridge the gap between academic education and industry requirements.
          </p>
        </div>
      </div>

      {/* Vision & Mission */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <img 
                src="https://picsum.photos/id/20/800/800" 
                alt="Vision" 
                className="rounded-3xl shadow-2xl"
              />
            </div>
            <div>
              <div className="mb-10">
                <div className="w-12 h-12 bg-brand-100 rounded-lg flex items-center justify-center text-brand-600 mb-4">
                  <Lightbulb />
                </div>
                <h2 className="text-3xl font-bold text-slate-900 mb-4">Our Vision</h2>
                <p className="text-slate-600 text-lg leading-relaxed">
                  To empower learners with industry-relevant skills and career confidence, creating a workforce that is ready to tackle modern business challenges from day one.
                </p>
              </div>
              
              <div>
                <div className="w-12 h-12 bg-accent-100 rounded-lg flex items-center justify-center text-accent-600 mb-4">
                  <Target />
                </div>
                <h2 className="text-3xl font-bold text-slate-900 mb-4">Our Mission</h2>
                <ul className="space-y-4">
                  {[
                    "Provide 100% practical, hands-on learning experiences.",
                    "Offer career guidance and mentorship from industry experts.",
                    "Build a supportive ecosystem for lifelong learning."
                  ].map((item, i) => (
                    <li key={i} className="flex items-start">
                      <ArrowRight className="w-5 h-5 text-accent-500 mr-3 mt-1 flex-shrink-0" />
                      <span className="text-slate-700 font-medium">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Who We Serve */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900">Who We Serve</h2>
            <div className="w-20 h-1 bg-brand-500 mx-auto mt-4 rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
             {[
               { title: "Students", desc: "Fresh graduates looking for their first break.", img: "https://picsum.photos/id/64/400/300" },
               { title: "Professionals", desc: "Working employees seeking upskilling.", img: "https://picsum.photos/id/119/400/300" },
               { title: "Career Switchers", desc: "People wanting to move into Tech/Data.", img: "https://picsum.photos/id/180/400/300" },
               { title: "Entrepreneurs", desc: "Founders wanting to learn business skills.", img: "https://picsum.photos/id/175/400/300" },
             ].map((item, idx) => (
               <div key={idx} className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300">
                 <img src={item.img} alt={item.title} className="w-full h-40 object-cover" />
                 <div className="p-6">
                   <h3 className="text-xl font-bold text-slate-900 mb-2">{item.title}</h3>
                   <p className="text-slate-600 text-sm">{item.desc}</p>
                 </div>
               </div>
             ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-slate-900 mb-6">Join Our Community</h2>
          <Button variant="primary" to="/contact">Get in Touch</Button>
        </div>
      </section>
    </Layout>
  );
};

export default About;