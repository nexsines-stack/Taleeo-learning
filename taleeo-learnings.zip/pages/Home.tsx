import React from 'react';
import { ArrowRight, CheckCircle2, ChevronRight, GraduationCap, Laptop, Trophy, Users } from 'lucide-react';
import Layout from '../components/Layout';
import Button from '../components/Button';
import CourseCard from '../components/CourseCard';
import { COURSES, FEATURES, TESTIMONIALS } from '../constants';

const Home: React.FC = () => {
  // Only show first 3 courses on home page
  const featuredCourses = COURSES.slice(0, 3);

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-slate-50 to-brand-50 pt-12 pb-20 lg:pt-24 lg:pb-32 overflow-hidden">
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-brand-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"></div>
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 bg-accent-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
            <div className="lg:w-1/2 text-center lg:text-left">
              <div className="inline-flex items-center px-4 py-2 rounded-full bg-white border border-brand-100 shadow-sm mb-6">
                <span className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse"></span>
                <span className="text-xs font-semibold text-brand-800 tracking-wide uppercase">New Cohort Starting Soon</span>
              </div>
              <h1 className="text-4xl lg:text-6xl font-extrabold text-slate-900 leading-tight mb-6">
                Unlock Your Potential with <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-600 to-accent-600">Job-Ready Skills</span>
              </h1>
              <p className="text-lg text-slate-600 mb-8 leading-relaxed max-w-2xl mx-auto lg:mx-0">
                Forget boring theory. Get practical, industry-oriented training in Data Analytics, Marketing, and Professional Skills designed to get you hired.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button variant="primary" to="/webinars">
                  Register for Free Webinar
                </Button>
                <Button variant="outline" to="/contact">
                  Talk to Our Team
                </Button>
              </div>
              <div className="mt-8 flex items-center justify-center lg:justify-start space-x-6 text-sm text-slate-500 font-medium">
                <span className="flex items-center"><CheckCircle2 className="w-4 h-4 mr-2 text-green-500" /> 100% Practical</span>
                <span className="flex items-center"><CheckCircle2 className="w-4 h-4 mr-2 text-green-500" /> Mentorship</span>
              </div>
            </div>
            
            <div className="lg:w-1/2 relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-white transform rotate-2 hover:rotate-0 transition-transform duration-500">
                <img 
                  src="https://picsum.photos/id/1/800/600" 
                  alt="Students learning" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6 text-white">
                  <p className="font-bold text-lg">"The mentorship changed my career trajectory completely."</p>
                  <p className="text-sm opacity-80 mt-1">- Amit, Placed at Deloitte</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Why Choose TALeeO Learnings?</h2>
            <p className="text-slate-600">We don't just teach course material; we build careers through a holistic approach.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {FEATURES.map((feature) => (
              <div key={feature.id} className="p-8 rounded-2xl bg-slate-50 border border-slate-100 hover:bg-white hover:shadow-xl transition-all duration-300 group">
                <div className="w-14 h-14 bg-white rounded-xl shadow-sm flex items-center justify-center text-brand-600 mb-6 group-hover:scale-110 transition-transform border border-slate-100">
                  <feature.icon className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{feature.title}</h3>
                <p className="text-slate-600 leading-relaxed text-sm">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Programs */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-4">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Our Popular Programs</h2>
              <p className="text-slate-600">Explore courses designed for current industry demands.</p>
            </div>
            <Button variant="outline" to="/programs">View All Programs <ArrowRight className="ml-2 w-4 h-4"/></Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredCourses.map((course) => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        </div>
      </section>

      {/* How We Work */}
      <section className="py-20 bg-white relative overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">How We Work</h2>
            <p className="text-slate-600">A simplified path from beginner to professional.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative">
            {/* Connecting Line (Desktop) */}
            <div className="hidden md:block absolute top-12 left-0 w-full h-0.5 bg-slate-200 -z-10"></div>

            {[
              { icon: Laptop, title: "Learn Concepts", desc: "Interactive live sessions" },
              { icon: GraduationCap, title: "Practice Hands-On", desc: "Real-time simulations" },
              { icon: Trophy, title: "Work on Projects", desc: "Build a portfolio" },
              { icon: Users, title: "Get Career Support", desc: "Resume & Mock Interviews" },
            ].map((step, index) => (
              <div key={index} className="text-center bg-white md:bg-transparent pt-4 md:pt-0">
                <div className="w-24 h-24 mx-auto bg-brand-50 rounded-full flex items-center justify-center text-brand-600 border-4 border-white shadow-lg mb-6 relative z-10">
                  <step.icon className="w-10 h-10" />
                  <div className="absolute top-0 right-0 bg-accent-500 text-white w-6 h-6 rounded-full text-xs flex items-center justify-center font-bold">
                    {index + 1}
                  </div>
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">{step.title}</h3>
                <p className="text-slate-600 text-sm">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-brand-900 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold mb-4">Success Stories</h2>
            <p className="text-brand-100 opacity-80">Don't just take our word for it.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {TESTIMONIALS.map((t) => (
              <div key={t.id} className="bg-brand-800 p-8 rounded-2xl border border-brand-700 relative">
                <div className="text-4xl text-brand-600 font-serif absolute top-4 left-4 opacity-50">"</div>
                <p className="mb-6 text-brand-100 relative z-10">{t.content}</p>
                <div className="flex items-center">
                  <img src={t.avatar} alt={t.name} className="w-12 h-12 rounded-full border-2 border-brand-500 mr-4" />
                  <div>
                    <h4 className="font-bold text-white">{t.name}</h4>
                    <p className="text-xs text-brand-300">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="bg-accent-50 rounded-3xl p-12 text-center border border-accent-100 shadow-xl max-w-5xl mx-auto relative overflow-hidden">
             {/* Decorative circles */}
             <div className="absolute top-0 left-0 -mt-10 -ml-10 w-40 h-40 bg-accent-100 rounded-full opacity-50"></div>
             <div className="absolute bottom-0 right-0 -mb-10 -mr-10 w-40 h-40 bg-accent-100 rounded-full opacity-50"></div>

            <h2 className="text-3xl md:text-5xl font-bold text-slate-900 mb-6 relative z-10">Ready to Upskill & Grow?</h2>
            <p className="text-lg text-slate-600 mb-8 max-w-2xl mx-auto relative z-10">
              Join thousands of learners who have transformed their careers with TALeeO Learnings.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center relative z-10">
              <Button variant="primary" to="/webinars" className="px-8 py-4 text-lg shadow-orange-500/30">
                Register for Webinar
              </Button>
              <Button variant="secondary" to="/contact" className="px-8 py-4 text-lg">
                Contact Us
              </Button>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Home;