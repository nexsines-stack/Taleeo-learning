import React from 'react';
import Layout from '../components/Layout';
import { Briefcase, MapPin, BadgeCheck, ArrowRight } from 'lucide-react';
import Button from '../components/Button';
import { INTERNSHIPS } from '../constants';

const Internships: React.FC = () => {
  return (
    <Layout>
      <div className="bg-slate-900 text-white py-16">
        <div className="container mx-auto px-4">
           <h1 className="text-3xl md:text-4xl font-bold mb-4">Internships & Careers</h1>
           <p className="text-slate-300 max-w-2xl">
             Gain real-world experience. We don't just train; we provide opportunities to work on live projects.
           </p>
        </div>
      </div>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 gap-8 max-w-5xl mx-auto">
            {INTERNSHIPS.map((job) => (
              <div key={job.id} className="border border-slate-200 rounded-2xl p-8 hover:border-brand-200 hover:shadow-lg transition-all bg-white relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-24 h-24 bg-brand-50 rounded-bl-full -mr-4 -mt-4 opacity-50 group-hover:bg-brand-100 transition-colors"></div>
                
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900 mb-2">{job.role}</h2>
                    <div className="flex space-x-4 text-sm text-slate-500">
                      <span className="flex items-center"><Briefcase className="w-4 h-4 mr-1" /> {job.type}</span>
                      <span className="flex items-center"><MapPin className="w-4 h-4 mr-1" /> {job.location}</span>
                    </div>
                  </div>
                  <div className="mt-4 md:mt-0">
                    <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold uppercase tracking-wide">Open</span>
                  </div>
                </div>

                <p className="text-slate-600 mb-6">{job.description}</p>

                <div className="mb-8">
                  <h4 className="text-sm font-semibold text-slate-900 mb-3 uppercase tracking-wider">Perks & Benefits</h4>
                  <div className="flex flex-wrap gap-3">
                    {job.benefits.map((b, i) => (
                      <span key={i} className="flex items-center bg-slate-50 text-slate-700 px-3 py-2 rounded-lg text-sm border border-slate-100">
                        <BadgeCheck className="w-4 h-4 text-brand-500 mr-2" /> {b}
                      </span>
                    ))}
                  </div>
                </div>

                <Button variant="outline" to="/contact" className="hover:bg-brand-600 hover:text-white hover:border-brand-600">
                  Apply via Form <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>

          {/* Mentorship Note */}
          <div className="mt-16 bg-gradient-to-r from-brand-600 to-brand-700 rounded-2xl p-8 md:p-12 text-white text-center max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">Looking for Mentorship?</h2>
            <p className="mb-8 opacity-90 max-w-2xl mx-auto">
              Not sure which career path fits you? Schedule a 1:1 mentorship call with our industry experts before applying.
            </p>
            <Button variant="primary" to="/contact" className="bg-white text-brand-700 hover:bg-slate-100 shadow-none border-0">
              Schedule Call
            </Button>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Internships;