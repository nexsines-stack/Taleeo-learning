import React, { useState } from 'react';
import Layout from '../components/Layout';
import { ChevronDown, ChevronUp, Shield, FileText, RefreshCcw } from 'lucide-react';

const Policies: React.FC = () => {
  const [activeSection, setActiveSection] = useState<string | null>('refund');

  const toggleSection = (section: string) => {
    setActiveSection(activeSection === section ? null : section);
  };

  return (
    <Layout>
      <div className="bg-slate-50 py-12 border-b border-gray-200">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold text-slate-900">Website Policies</h1>
          <p className="text-slate-600 mt-2">Transparency is key to our relationship with learners.</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        <div className="space-y-6">
          
          {/* Refund Policy */}
          <div className="border border-gray-200 rounded-xl overflow-hidden shadow-sm bg-white">
            <button 
              onClick={() => toggleSection('refund')}
              className="w-full flex items-center justify-between p-6 bg-white hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-accent-100 flex items-center justify-center text-accent-600 mr-4">
                  <RefreshCcw className="w-5 h-5" />
                </div>
                <h2 className="text-xl font-bold text-slate-900">Refund Policy</h2>
              </div>
              {activeSection === 'refund' ? <ChevronUp className="text-slate-400" /> : <ChevronDown className="text-slate-400" />}
            </button>
            
            {activeSection === 'refund' && (
              <div className="p-6 pt-0 border-t border-gray-100 text-slate-600 leading-relaxed">
                <p className="mb-4">At TALeeO Learnings, we strive to provide the highest quality education. However, we understand that circumstances change.</p>
                <h3 className="font-bold text-slate-900 mb-2">Conditions for Refund:</h3>
                <ul className="list-disc pl-5 space-y-2 mb-4">
                  <li>Refund requests must be made within 7 days of course purchase.</li>
                  <li>Less than 25% of the course content must have been consumed.</li>
                  <li>For live workshops/webinars, cancellations must be made 24 hours prior to the event.</li>
                </ul>
                <p>To request a refund, please email us at <span className="font-semibold text-brand-600">taleeolearnings@gmail.com</span> with your order details. Refunds are processed within 5-7 working days.</p>
              </div>
            )}
          </div>

          {/* Privacy Policy */}
          <div className="border border-gray-200 rounded-xl overflow-hidden shadow-sm bg-white">
            <button 
              onClick={() => toggleSection('privacy')}
              className="w-full flex items-center justify-between p-6 bg-white hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center">
                 <div className="w-10 h-10 rounded-full bg-brand-100 flex items-center justify-center text-brand-600 mr-4">
                  <Shield className="w-5 h-5" />
                </div>
                <h2 className="text-xl font-bold text-slate-900">Privacy Policy</h2>
              </div>
              {activeSection === 'privacy' ? <ChevronUp className="text-slate-400" /> : <ChevronDown className="text-slate-400" />}
            </button>
            
            {activeSection === 'privacy' && (
              <div className="p-6 pt-0 border-t border-gray-100 text-slate-600 leading-relaxed">
                <p className="mb-4">Your privacy is important to us. This policy outlines how we collect, use, and protect your personal information.</p>
                <h3 className="font-bold text-slate-900 mb-2">Data Collection:</h3>
                <p className="mb-4">We collect information such as name, email, and phone number when you register for courses or webinars. We do not store payment card details on our servers.</p>
                <h3 className="font-bold text-slate-900 mb-2">Usage:</h3>
                <p>We use your data to provide course access, send updates, and improve our services. We do not sell your data to third parties.</p>
              </div>
            )}
          </div>

           {/* Terms */}
           <div className="border border-gray-200 rounded-xl overflow-hidden shadow-sm bg-white">
            <button 
              onClick={() => toggleSection('terms')}
              className="w-full flex items-center justify-between p-6 bg-white hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center">
                 <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 mr-4">
                  <FileText className="w-5 h-5" />
                </div>
                <h2 className="text-xl font-bold text-slate-900">Terms & Conditions</h2>
              </div>
              {activeSection === 'terms' ? <ChevronUp className="text-slate-400" /> : <ChevronDown className="text-slate-400" />}
            </button>
            
            {activeSection === 'terms' && (
              <div className="p-6 pt-0 border-t border-gray-100 text-slate-600 leading-relaxed">
                <p className="mb-4">By accessing this website, you agree to be bound by these Terms and Conditions.</p>
                <h3 className="font-bold text-slate-900 mb-2">Intellectual Property:</h3>
                <p className="mb-4">All course materials, videos, and resources are the intellectual property of TALeeO Learnings. Unauthorized distribution is prohibited.</p>
                <h3 className="font-bold text-slate-900 mb-2">User Conduct:</h3>
                <p>Users must maintain professional behavior in community forums and live sessions. Harassment or hate speech will result in immediate account termination.</p>
              </div>
            )}
          </div>

        </div>
      </div>
    </Layout>
  );
};

export default Policies;