import React, { useState } from 'react';
import Layout from '../components/Layout';
import CourseCard from '../components/CourseCard';
import { COURSES } from '../constants';
import { Filter } from 'lucide-react';

const Programs: React.FC = () => {
  const [filter, setFilter] = useState<string>('All');
  const categories = ['All', 'Data', 'Business', 'Marketing', 'Tech'];

  const filteredCourses = filter === 'All' 
    ? COURSES 
    : COURSES.filter(c => c.category === filter);

  return (
    <Layout>
      <div className="bg-slate-50 py-12 border-b border-slate-200">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold text-slate-900 mb-4">Our Programs</h1>
          <p className="text-slate-600 max-w-2xl">
            Explore our wide range of industry-oriented programs designed to help you master new skills and advance your career.
          </p>
        </div>
      </div>

      <div className="py-12">
        <div className="container mx-auto px-4">
          {/* Filters */}
          <div className="flex flex-wrap items-center gap-4 mb-10 pb-6 border-b border-gray-100">
            <div className="flex items-center text-slate-500 mr-4">
              <Filter className="w-5 h-5 mr-2" />
              <span className="font-medium">Filter by:</span>
            </div>
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                  filter === cat 
                    ? 'bg-brand-600 text-white shadow-md' 
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Grid */}
          {filteredCourses.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredCourses.map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-slate-50 rounded-2xl border border-dashed border-slate-300">
              <p className="text-slate-500">No programs found in this category.</p>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default Programs;