import React from 'react';
import Layout from '../components/Layout';
import { Calendar, Clock, Video, CheckCircle } from 'lucide-react';
import Button from '../components/Button';
import { WEBINARS } from '../constants';

const Webinars: React.FC = () => {
  return (
    <Layout>
      <div className="bg-brand-900 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <span className="inline-block py-1 px-3 rounded bg-accent-500 text-white text-xs font-bold tracking-wider mb-4">FREE SESSIONS</span>
          <h1 className="text-4xl font-bold mb-4">Upcoming Live Webinars</h1>
          <p className="text-brand-100 max-w-xl mx-auto">
            Join our expert-led sessions to get a glimpse of industry trends, tools, and career hacks.
          </p>
        </div>
      </div>

      <section className="py-16 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto space-y-8">
            {WEBINARS.map((webinar) => (
              <div key={webinar.id} className="bg-white rounded-2xl p-6 md:p-8 shadow-sm hover:shadow-md transition-shadow border border-gray-100 flex flex-col md:flex-row gap-8">
                {/* Date Badge */}
                <div className="flex-shrink-0 flex flex-col items-center justify-center bg-brand-50 w-full md:w-32 h-32 rounded-xl text-brand-700">
                  <span className="text-3xl font-bold">{webinar.date.split(' ')[1]}</span>
                  <span className="text-sm font-medium uppercase">{webinar.date.split(' ')[0]}</span>
                </div>

                <div className="flex-grow">
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">{webinar.title}</h3>
                  <div className="flex flex-wrap gap-4 text-sm text-slate-600 mb-6">
                    <span className="flex items-center"><Clock className="w-4 h-4 mr-1 text-accent-500" /> {webinar.time}</span>
                    <span className="flex items-center"><Video className="w-4 h-4 mr-1 text-accent-500" /> Online (Zoom)</span>
                    <span className="font-medium text-brand-600">By {webinar.speaker}</span>
                  </div>

                  <div className="mb-6">
                    <h4 className="text-sm font-semibold text-slate-900 mb-2">What you will learn:</h4>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {webinar.topics.map((topic, i) => (
                        <li key={i} className="flex items-center text-sm text-slate-600">
                          <CheckCircle className="w-3 h-3 text-green-500 mr-2" /> {topic}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <Button variant="primary" onClick={() => alert(`Registered for ${webinar.title}!`)}>
                    Register for Free
                  </Button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 bg-white rounded-2xl p-8 border border-gray-100 text-center shadow-lg max-w-4xl mx-auto">
            <h3 className="text-xl font-bold mb-4">Why attend our webinars?</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
               <div className="p-4 bg-brand-50 rounded-lg">
                 <h4 className="font-bold text-brand-700 mb-2">Interactive Q&A</h4>
                 <p className="text-sm text-slate-600">Get your doubts cleared instantly by experts.</p>
               </div>
               <div className="p-4 bg-brand-50 rounded-lg">
                 <h4 className="font-bold text-brand-700 mb-2">Live Demos</h4>
                 <p className="text-sm text-slate-600">See tools and techniques in action.</p>
               </div>
               <div className="p-4 bg-brand-50 rounded-lg">
                 <h4 className="font-bold text-brand-700 mb-2">Exclusive Offers</h4>
                 <p className="text-sm text-slate-600">Get discounts on full courses for attending.</p>
               </div>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Webinars;