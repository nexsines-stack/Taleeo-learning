import { LucideIcon } from 'lucide-react';

export interface Course {
  id: string;
  title: string;
  category: 'Data' | 'Marketing' | 'Business' | 'Tech';
  description: string;
  duration: string;
  image: string;
  price?: string;
}

export interface Feature {
  id: number;
  title: string;
  description: string;
  icon: LucideIcon;
}

export interface Testimonial {
  id: number;
  name: string;
  role: string;
  content: string;
  avatar: string;
}

export interface Internship {
  id: string;
  role: string;
  type: string;
  location: string;
  description: string;
  benefits: string[];
}

export interface Webinar {
  id: string;
  title: string;
  date: string;
  time: string;
  speaker: string;
  topics: string[];
}